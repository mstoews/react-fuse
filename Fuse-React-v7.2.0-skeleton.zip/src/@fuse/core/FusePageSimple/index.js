export { default } from './FusePageSimple';
